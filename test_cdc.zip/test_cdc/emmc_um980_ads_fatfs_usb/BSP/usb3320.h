///*
// * usb_storage.h
// *
// *  Created on: 2023��10��19��
// *      Author: pc
// */

//#ifndef APP_USB_STORAGE_H_
//#define APP_USB_STORAGE_H_

//#include "main.h"


//uint8_t usb_storage_init(void);
//uint8_t usb_storage_read(uint8_t* pBuffer,uint32_t ReadAddr,uint16_t NumByteToRead);
//uint8_t usb_storage_write(uint8_t* pBuffer,uint32_t WriteAddr,uint16_t NumByteToWrite);

//#endif /* APP_USB_STORAGE_H_ */
